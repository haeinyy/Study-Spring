package com.ssafy.mvc.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class ExceptionController {
	@ExceptionHandler(Exception.class)
	public String error(Model m, Exception e) {
		e.printStackTrace();
		m.addAttribute("msg",e.getMessage());
		return "error/500";
	}

}
