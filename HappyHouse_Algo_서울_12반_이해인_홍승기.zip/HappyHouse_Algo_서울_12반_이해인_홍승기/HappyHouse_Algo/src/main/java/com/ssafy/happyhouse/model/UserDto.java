package com.ssafy.happyhouse.model;

public class UserDto {
	
	private String userId;
	private String userPass;
	private String userName;
	private String userPhone;
	private String userAddress;
	
	
	public UserDto() {};
	
	public UserDto(String userId, String userPass, String userName, String userPhone,
			String userAddress) {
		this.userId = userId;
		this.userPass = userPass;
		this.userName = userName;
		this.userPhone = userPhone;
		this.userAddress = userAddress;
	}

	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPass() {
		return userPass;
	}
	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserDto [userId=").append(userId).append(", userPass=").append(userPass)
				.append(", userName=").append(userName).append(", userPhone=").append(userPhone)
				.append(", userAddress=").append(userAddress).append("]");
		return builder.toString();
	}
	
	
	
	
}
