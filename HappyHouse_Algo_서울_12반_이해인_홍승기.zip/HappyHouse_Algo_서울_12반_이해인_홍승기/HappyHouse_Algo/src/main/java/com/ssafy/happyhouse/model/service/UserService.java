package com.ssafy.happyhouse.model.service;

import java.util.Map;

import com.ssafy.happyhouse.model.UserDto;

public interface UserService {
	
	int idCheck(String id) throws Exception;
	int registerUser(UserDto userDto) throws Exception; // 회원가입 - error발생이지 insert실패가 아니야 
//	UserDto login(String id, String pass) throws Exception;
	UserDto login(Map<String,String> map) throws Exception;
	UserDto getUser(String id) throws Exception; // 한 사람의 정보 가져오기
	int updateUser(UserDto userDto) throws Exception;
	int deleteUser(String id) throws Exception;
}
