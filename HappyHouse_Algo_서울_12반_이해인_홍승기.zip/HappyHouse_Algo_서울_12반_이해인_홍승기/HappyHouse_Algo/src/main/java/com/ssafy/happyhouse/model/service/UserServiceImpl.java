package com.ssafy.happyhouse.model.service;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.mapper.UserMapper;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public int idCheck(String id) throws Exception {
		return sqlSession.getMapper(UserMapper.class).idCheck(id);
	}

	@Override
	public int registerUser(UserDto userDto) throws Exception {
		return sqlSession.getMapper(UserMapper.class).registerUser(userDto);
	}

	@Override
	public UserDto login(Map<String, String> map) throws Exception {
		return sqlSession.getMapper(UserMapper.class).login(map);
	}

	@Override
	public UserDto getUser(String id) throws Exception {
		return sqlSession.getMapper(UserMapper.class).getUser(id);
	}

	@Override
	public int updateUser(UserDto userDto) throws Exception {
		return sqlSession.getMapper(UserMapper.class).updateUser(userDto);
	}

	@Override
	public int deleteUser(String id) throws Exception {
		return sqlSession.getMapper(UserMapper.class).deleteUser(id);
	}

}
