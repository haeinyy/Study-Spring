
package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.service.HappyHouseMapService;

// index page 처리용 controller
@Controller
public class MainController {
	
	@Autowired
	private HappyHouseMapService happyHouseMapService;

	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/map")
	public String map() {
		return "MapSearch";
	}
	
	@GetMapping("/user")
	public String userlogin() {
		return "user/login";
	}
	
	@GetMapping("/register")
	public String registerUser() { // @RequestBody : json 데이터를 원하는 타입으로 바인딩
		return "user/join";
	}
	

}
