// https://console.developers.google.com    key받기 위한 site
var root = "";

// 마커를 담을 배열입니다
var markers = [];
console.log("tlfgod");
var mapContainer = document.getElementById("map"); // 지도를 표시할 div	
var mapOption = {
	    center: new kakao.maps.LatLng(37.566826, 126.9786567), // 지도의 중심좌표
	    level: 3, // 지도의 확대 레벨
	};

// 지도를 생성합니다
var map = new kakao.maps.Map(mapContainer, mapOption);

// 장소 검색 객체를 생성합니다
var ps = new kakao.maps.services.Places();

// 검색 결과 목록이나 마커를 클릭했을 때 장소명을 표출할 인포윈도우를 생성합니다
var infowindow = new kakao.maps.InfoWindow({ zIndex: 1 });
// 커스텀 오버레이를 생성합니다
var customOverlay;
//주소-좌표 변환 객체를 생성합니다
var geocoder = new kakao.maps.services.Geocoder();

let gps = document.querySelector('#gps');
console.log(gps);

gps.addEventListener("click", function(){
	console.log("hi~");
	let places = [];
	let check = false;
	if(navigator.geolocation){
		navigator.geolocation.getCurrentPosition(function(position){
			let lat = position.coords.latitude,
				lon = position.coords.longitude;
			
			//console.log(lat, lon);
			
			let locPosition = new kakao.maps.LatLng(lat, lon);
			let gucode = null;
			let guname = null;
			
			
			searchDetailAddrFromCoords(locPosition, function(result, status){
				if(status == kakao.maps.services.Status.OK){
					guname = result[0].address.region_2depth_name;
					console.log(result);
					
					$.get("/map/findcode"
		                     ,{gugun: result[0].address.region_2depth_name}
		                     ,function(data, status){
		                        console.log(data);
		                        gucode = data;
		                     }
		                     , "json"
		               ).then(()=>{
		                  let param = {
		                        serviceKey:'pc39AHl8dueAJyHUvl8sbKuAqCUNw1FEQ5tJ3iYa1N2QJfxKkf0MGVFYLtZZw6XNmgxrN+8fwQjOK+2ZbDIPbw==',
		                        pageNo:encodeURIComponent('1'),
		                        numOfRows:encodeURIComponent('100'),
		                        LAWD_CD:encodeURIComponent(gucode),
		                        DEAL_YMD:encodeURIComponent('202110')
		                  };
		                  console.log(param);
		                  var jsonArray = new Array();
		                  $.get('http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev'
		                        ,param
		                        ,function(data, status){
		                           console.log(data);
		                           var items = $(data).find('item');
		                           
		                           items.each(function() {
		                              var jsonObj   = new Object();
		                              jsonObj.aptCode = $(this).find('일련번호').text();
		                              jsonObj.aptName = $(this).find('아파트').text();
		                              jsonObj.dongCode = $(this).find('법정동읍면동코드').text();
		                              jsonObj.road = guname+" "+$(this).find('도로명').text();
		                           
		                              //jsonObj.dongName = ;
		                              //jsonObj.sidoName = ;
		                              //jsonObj.gugunName = ;
		                              jsonObj.buildYear = $(this).find('건축년도').text();
		                              jsonObj.jibun = $(this).find('지번').text();
		                              jsonObj.recentPirce = $(this).find('거래금액').text();
		                              let fcode = "";
		                              let first = $(this).find('도로명건물본번호코드').text();
		                              for(let i = 0; i < first.length; i++){
		                            	  if(first[i] == '0'){
		                            		  continue;
		                            	  }
		                            	  fcode += first[i];
		                              }
		                              let second = $(this).find('도로명건물부번호코드').text();
		                              let scode = "";
		                              for(let i = 0; i < second.length; i++){
		                            	  if(second[i] == '0') continue;
		                            	  scode += second[i];
		                              }
		                              let realcode = "";
		                              if(scode != ""){
		                            	  realcode = fcode + "-" + scode;		                              
		                              }
		                              else realcode = fcode;
		                              
		                              //console.log(realcode);
		                              jsonObj.road += " "+realcode;
		                              jsonObj = JSON.stringify(jsonObj);
		                              //String 형태로 파싱한 객체를 다시 json으로 변환
		                              
		                              jsonArray.push(JSON.parse(jsonObj));
		                              ///geocoder.addressSearch(, callback);
		                           });
		                           
		                           
		                           //console.log(jsonArray);
		                           //displayMarkers(jsonArray);
		                        }
		                        , "xml"
		                  ).then(()=>{
		                	  var callback = function(result, status) {
	                        	   check = true; 
	                        	   if (status === kakao.maps.services.Status.OK) {
                           	        console.log(typeof result[0].y);
                           	        places.push({
                           	        	lat : result[0].y,
                           	        	lng : result[0].x
                           	        });
                           	        console.log(places.length);
                           	        console.log(check);
                           	    }
                              };
                              jsonArray.forEach((e,i)=>{
	                           	  let str = guname +" "+e.aptName;
	                           	  //console.log(e.road);
	                           	  geocoder.addressSearch(e.road, callback);
                              })
		                  });  
		               });
		            }
		         })
		
			setTimeout(displayMarkers,1000, places, locPosition);
			//console.log(locPosition);
			//GpsDisplayMarker(locPosition);
		})
	}
});
function searchDetailAddrFromCoords(coords, callback) {
    // 좌표로 법정동 상세 주소 정보를 요청합니다
    geocoder.coord2Address(coords.getLng(), coords.getLat(), callback);
}
function GpsDisplayMarker(locPosition) {

    // 마커를 생성합니다
	removeMarker();
    var marker = addMarker(locPosition,0); 
    map.setCenter(locPosition);      
} 


//검색 결과 목록과 마커를 표출하는 함수입니다
function displayMarkers(places, center) {
	var fragment = document.createDocumentFragment();
    var bounds = new kakao.maps.LatLngBounds();
    var listStr = "";
    console.log(places, places.length, center);
    if(center){
		map.setCenter(center);
	}
	// 지도에 표시되고 있는 마커를 제거합니다
	removeMarker();
	for(var i=0; i<places.length; i++) {
		console.log("dfasdfasdfasdfasdf");
		var placePosition = new kakao.maps.LatLng(places[i].lat, places[i].lng);
		console.log(placePosition);
		var marker = addMarker(placePosition, i);
		var itemEl = getListItem(i, places[i]); // 검색 결과 항목 Element를 생성합니다
		
		// 검색된 장소 위치를 기준으로 지도 범위를 재설정하기위해
		// LatLngBounds 객체에 좌표를 추가합니다
		bounds.extend(placePosition);
		// 마커와 검색결과 항목에 mouseover 했을때
		// 해당 장소에 인포윈도우에 장소명을 표시합니다
		// mouseout 했을 때는 인포윈도우를 닫습니다
		(function (marker, title, code, place) {
			kakao.maps.event.addListener(marker, "click", function () {
				displayInfowindow(marker, title, place);
				console.log(title + " " + code);
			});

		    kakao.maps.event.addListener(map, "click", function () {
		    	console.log(customOverlay);
		    	customOverlay.setMap(null);
		    });

		    itemEl.onmouseover = function () {
		    	displayInfowindow(marker, title);
		    };

		    itemEl.onmouseout = function () {
		    	customOverlay.setMap(null);
		    };
		})(marker, places[i].aptName, places[i].aptCode, places[i]);

		fragment.appendChild(itemEl);
	}
	// 마커를 생성하고 지도에 표시합니다 

	// 검색된 장소 위치를 기준으로 지도 범위를 재설정합니다
	map.setBounds(bounds);
	console.log(markers);
	
}

//마커를 생성하고 지도 위에 마커를 표시하는 함수입니다
function addMarker(position, idx, title) {
	var imageSrc = "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_number_blue.png", // 마커 이미지 url, 스프라이트 이미지를 씁니다
	imageSize = new kakao.maps.Size(36, 37), // 마커 이미지의 크기
	imgOptions = {
		spriteSize: new kakao.maps.Size(36, 691), // 스프라이트 이미지의 크기
		spriteOrigin: new kakao.maps.Point(0, idx * 46 + 10), // 스프라이트 이미지 중 사용할 영역의 좌상단 좌표
		offset: new kakao.maps.Point(13, 37), // 마커 좌표에 일치시킬 이미지 내에서의 좌표
	},
	markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize, imgOptions),
	marker = new kakao.maps.Marker({
		position: position, // 마커의 위치
		image: markerImage,
	});

	marker.setMap(map); // 지도 위에 마커를 표출합니다
	markers.push(marker); // 배열에 생성된 마커를 추가합니다

	return marker;
}

// 지도 위에 표시되고 있는 마커를 모두 제거합니다
function removeMarker() {
	for (var i = 0; i < markers.length; i++) {
		markers[i].setMap(null);
	}
	markers = [];
}

//검색결과 항목을 Element로 반환하는 함수입니다
function getListItem(index, place) {
	var el = document.createElement("li");
	var itemStr = `
		<span class="markerbg marker_${index + 1}></span>
		<div class="info"><h5>${place.aptName}</h5> <button>관심등록</button>
		<span>${place.sidoName} ${place.gugunName} ${place.dongName} ${place.jibun}</span>
	`;
	el.innerHTML = itemStr;
	el.className = "item";

	return el;
}

//검색결과 목록 또는 마커를 클릭했을 때 호출되는 함수입니다
//인포윈도우에 장소명을 표시합니다
function displayInfowindow(marker, title, place) {
	console.log(title);
	var content = `
		<div class="overlaybox">
			<div class="boxtitle">${title}</div>
			<div class="first"><img src="${root}/img/apt.png" style="width:247px; height:136px;" alt=""></div>
			<ul>
				<li class="up">
					<span class="title">건축년도</span>
					<span class="count">${place.buildYear}</span>
				</li>
				<li>
					<span class="title">주소</span>
					<span class="count">${place.sidoName} ${place.gugunName} ${place.dongName} ${place.jibun}</span>
				</li>
				<li>
					<span class="title">최신거래금액</span>
					<span class="count">${place.recentPrice}</span>
				</li>
				<li>
					<span class="last" id="recenthistor" data-toggle="modal" data-target="#myModal">아파트정보 update</span>
				</li>
			</ul>
		</div>
	`;
	var position = new kakao.maps.LatLng(marker.getPosition().getLat()+0.00033, marker.getPosition().getLng()-0.00003);
	customOverlay = new kakao.maps.CustomOverlay({
		position: position,
		content: content,
		xAnchor: 0.3,
		yAnchor: 0.91,
	});
	customOverlay.setMap(map);
}

//검색결과 목록의 자식 Element를 제거하는 함수입니다
function removeAllChildNods(el) {
	while (el.hasChildNodes()) {
		el.removeChild(el.lastChild);
	}
}
///////////////////////////////////////////////////////////////

function logout() {
    var list = document.querySelectorAll(".nav-logout");
    for (let i = 0; i < list.length; i++) {
        list[i].style.display = "none";

    }
    list = document.querySelectorAll(".nav-login");
    for (let i = 0; i < list.length; i++) {
        list[i].style.display = "";
    }
    // document.querySelector(".nav-logout").style.display = "none";
    // document.querySelector(".nav-login").style.display = "";
}

function login() {
    // var s = opener.document.getElementById("#nav-login");
    var list = opener.document.querySelectorAll(".nav-logout");
    for (let i = 0; i < list.length; i++) {
        list[i].style.display = "";

    }
    list = opener.document.querySelectorAll(".nav-login");
    for (let i = 0; i < list.length; i++) {
        list[i].style.display = "none";
    }

    // opener.document.querySelector(".nav-logout").style.display = "";
    // opener.document.querySelector(".nav-login").style.display = "none";
    alert('로그인 성공.');
    self.close();
}
function update() {
    // var s = opener.document.getElementById("#nav-login");
    alert('정보 수정 성공.');
    self.close();
}
function open_win() {
    window.open("login.html");
}
function open_join() {
    window.open("join.html");
}
function open_info() {
    window.open("info.html");
}
function join() {
    alert('회원 가입 완료.');
    self.close();
}
function update() {
    alert('정보 수정 성공.');
    self.close();
}
function out() {
    alert('회원 탈퇴 완료.');
    self.close();
}