package com.ssafy.ws.model.service;

import com.ssafy.ws.dto.User;

public interface UserService {
	User select(String id);
}
